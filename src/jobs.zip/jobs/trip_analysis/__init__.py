from jobs.trip_analysis.main import analyze
from jobs.trip_analysis.location import analyze_location
from jobs.trip_analysis.duration import analyze_duration