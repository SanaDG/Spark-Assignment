def shared_function():
    print('put your shared logic between jobs here')
